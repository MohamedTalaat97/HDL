# importing pandas module
import pandas as pd
import os.path

save_path = 'E:/Data Collection Sheets (HDL)'

name_of_file = 'performance document'

completeName = os.path.join(save_path, name_of_file+".xlsx")

# Creating a new data frame

newDataframe = pd.DataFrame()

#offering section
OfferingActivitySection_txt = 'OfferingSectionId|EffectiveStartDate|EffectiveEndDate|OfferingSectionNumber|SectionPosition|OfferingId|OfferingNumber|Title|Description|DescriptionText|NumberOfActivitiesToComplete|CompletionRuleType|SequenceRuleSectionNumber|SequenceRuleType|SourceSystemOwner|SourceSystemId|GUID'
OfferingActivitySection_list = OfferingActivitySection_txt.split('|')
OfferingActivitySection_v = '|2023/07/11||OFFERING11-HDL_SEC|2||offering11|abc||desc|||||MOBILY|3435|'
OfferingActivitySection_v_list = OfferingActivitySection_v.split('|')


#self paced activity
SelfPacedActivity_txt = 'ActivityId|EffectiveStartDate|EffectiveEndDate|ActivityNumber|ActivityPosition|Title|Description|ExpectedEffort|SelfCompleteFlag|CompletionRuleType|SequenceRuleActivityNumber|SequenceRuleType|ContentId|ContentNumber|OfferingSectionId|OfferingSectionNumber|SourceType|SourceId|SourceInfo|SourceSystemOwner|SourceSystemId|GUID'
SelfPacedActivity_list = SelfPacedActivity_txt.split('|')
SelfPacedActivity_v = '|2023/07/11||SP-ACT1-03282122-HDL|1|Title:SP ACT1 202103282122-HDL||8|Y|||ORA_ACTIVITY_ANYTIME||||OFFERING11-HDL_SEC||||||'
SelfPacedActivity_v_list = SelfPacedActivity_v.split('|')


#instructor 
InstructorLedActivity_txt = 'ActivityId|EffectiveStartDate|EffectiveEndDate|ActivityNumber|ExpectedEffort|SourceSystemOwner|SourceSystemId|Title|ShortDescription|Description|CompletionRuleType|VirtualClassroomUrl|SelfCompleteFlag|TimeZone|OfferingSectionId|ActivityPosition|SequenceRuleType|DescriptionText|OfferingSectionNumber|ActivityDate|ActivityStartTime|ActivityEndTime|SequenceRuleActivityNumber|ClassroomResourceId|ClassroomResourceNumber'
InstructorLedActivity_list = InstructorLedActivity_txt.split('|')
InstructorLedActivity_v = '|2023/07/11||SP-ACT2-02122-HDL|5|MOBILY|ttk|title|desc|||||||4|||OFFERING11-HDL_SEC||||||'
InstructorLedActivity_v_list = InstructorLedActivity_v.split('|')

#model profile
model_txt = 'SourceSystemOwner|SourceSystemId|ProfileCode|ProfileTypeCode|ProfileStatusCode|ProfileUsageCode|Description|Summary'
model_list = model_txt.split('|')
model_v = 'VISION|LD_PRG_MP|LD_PRG|JOB|A|M|Lead programmer|Profile for lead programmer job.'
model_v_list = model_v.split('|')

#model certificate
model_cert_txt = 'CertificationId|ProfileId|ProfileCode|SectionId|ContentItemName|DateFrom|DateTo|Title|CertificationNumber|CountryCode|StateProvinceCode|IssuedBy|IssueDate|OriginalIssueYear|ExpirationDate|RenewalDate|LastRenewalDate|RenewalInprogressFlag|RenewalRequiredFlag|ActualCompletionDate|SourceSystemOwner|SourceSystemId'
model_cert_list = model_cert_txt.split('|')
model_cert_v = '||LD_PRG|300000029806485|Certificate|2023/07/12||certiv|456765|SA|||2023/07/12||2024/07/12|2024/07/12|||||MOBILY|tst1'
model_cert_v_list = model_cert_v.split('|')


#model comptencay 
model_comp_txt = 'SourceSystemOwner|SourceSystemId|ProfileId(SourceSystemId)|DateFrom|SectionId|ContentItemName|MinProfModelCode|MinProfLevelCode|MaxProfModelCode|MaxProfLevelCode|Weight|MinWeight|RequiredFlag|Importance'
model_comp_list = model_comp_txt.split('|')
model_comp_v = 'MOBILY|LD_PRG_MP_COM-ADA|LD_PRG_MP|2022/01/01|300000029806438|Core.C2.Team Player|PROFICIENCY|3|PROFICIENCY|5|80|50|N|'
model_comp_v_list = model_comp_v.split('|')


#model education
model_edu_txt = 'EducationId|ProfileCode|SectionId|ContentItemName|DegreeName|Major|SchoolName|StartDate|EndDate|CountryCode|City|AvgGrade|Gpa|RequiredGpa|GraduatedFlag|Title|HighestEduLevel|Importance|SourceSystemOwner|SourceSystemId'
model_edu_list = model_edu_txt.split('|')
model_edu_v = '|LD_PRG|300000029806465|PHD||||2023/01/01||SA||||||maor|||MOBILY|fjr'
model_edu_v_list = model_edu_v.split('|')


#model lang
model_lang_txt = 'SourceSystemOwner|SourceSystemId|ProfileId(SourceSystemId)|DateFrom|SectionId|IsLinkedIn|ContentItemName|ReadingLevelCode|SpeakingModelCode|SpeakingLevelCode|WritingModelCode|WritingLevelCode|AbleToTranslateFlag|AbleToTeachFlag|RequiredFlag|Importance'
model_lang_list = model_lang_txt.split('|')
model_lang_v = 'MOBILY|LD_PRG_MP_LAN-ENG|LD_PRG_MP|2023/01/01|300000029806475|N|Afar||||||N|N|Y|'
model_lang_v_list = model_lang_v.split('|')


#person profile





# Splitting the list into two pandas columns, one for the "Player Name" and

# the second one for the Country using slicing.
for head,data in zip(dev_goal_list,dev_goal_list_v):
    newDataframe[head] = [data]


save_path = 'E:/Data Collection Sheets (HDL)'

name_of_file = 'dev goal'

completeName = os.path.join(save_path, name_of_file+".xlsx")
# Converting the data frame to an excel file
newDataframe.to_excel(completeName, index = False)

# Reading the data from the outputExcelFile
excelData=pd.read_excel(completeName)

#Printing the data frame
print(excelData)