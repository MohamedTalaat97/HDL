# importing pandas module
import pandas as pd
import os.path

save_path = 'E:/Data Collection Sheets (HDL)'

name_of_file = 'performance document'

completeName = os.path.join(save_path, name_of_file+".xlsx")

# Creating a new data frame

newDataframe = pd.DataFrame()

pd_txt = 'AssignmentNumber|CustomaryName|StartDate|EndDate|Operation|ManagerAssignmentNumber'
pd_list = pd_txt.split('|')
pd_values = 'E107462|YEE2|2023/01/01|2023/12/31|ORA_CREATE_PD|E107161'
pd_list_v = pd_values.split('|')

# Splitting the list into two pandas columns, one for the "Player Name" and

# the second one for the Country using slicing.
for head,data in zip(dev_goal_list,dev_goal_list_v):
    newDataframe[head] = [data]


save_path = 'E:/Data Collection Sheets (HDL)'

name_of_file = 'dev goal'

completeName = os.path.join(save_path, name_of_file+".xlsx")
# Converting the data frame to an excel file
newDataframe.to_excel(completeName, index = False)

# Reading the data from the outputExcelFile
excelData=pd.read_excel(completeName)

#Printing the data frame
print(excelData)