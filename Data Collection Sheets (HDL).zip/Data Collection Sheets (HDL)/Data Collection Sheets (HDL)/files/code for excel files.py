# importing pandas module
import pandas as pd

# input list
instructor_txt = 'InstructorResourceNumber|PersonId|PersonNumber|TrainingSupplierResourceNumber|OwnedByPersonNumber|SourceType(=Instructor)|SourceId|SourceSystemId|SourceSystemOwner(=MOBILY)'
instructor_list  = instructor_txt.split('|')

classroom_txt = 'ClassroomResourceNumber|Title|Description|Capacity|ContactNumber|LocationId(location id from fusion instance)|SourceType(=Classroom)|OwnedByPersonNumber|SourceSystemOwner(=MOBILY)|SourceSystemId'
classroom_list  = classroom_txt.split('|')

training_supllier_txt = 'TrainingSupplierResourceNumber|Title|Description|ContactNumber|Status|SourceId|SourceType|OwnedByPersonId|OwnedByPersonNumber|SourceSystemId|SourceSystemOwner' 


# Creating a new data frame
newDataframe = pd.DataFrame()

# Splitting the list into two pandas columns, one for the "Player Name" and

# the second one for the Country using slicing.
for ele in instructor_list:
    newDataframe[ele] = ''


# Converting the data frame to an excel file
newDataframe.to_excel('ins.xlsx', index = False)

# Reading the data from the outputExcelFile
excelData=pd.read_excel('ins.xlsx')

#Printing the data frame
print(excelData)